let hours_worked = [20; 27; 25]
